const express = require("express");
const User = require("../../models/AuctionUser");
const router = express.Router();
const gravatar = require("gravatar");
const jwt = require("jsonwebtoken");
const { check, validationResult } = require("express-validator");
const bcrypt = require("bcryptjs");
const config = require("config");
const auth = require("../../middleware/auth");
//  @route  GET /api/users
//  @desc   Get all users
//  @access private
router.get("/", auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    if (user.isAdmin === true) {
      users = await User.find().select("-password");
      res.json(users);
    } else {
      return res.status(400).send({ msg: "User not authorised" });
    }
  } catch (err) {
    console.error(err);
    res.status(500).send({ msg: "Server Error" });
  }
});

//  @route  POST /api/users
//  @desc   Register a User
//  @access public
router.post(
  "/",
  [
    check("name", "Name is required")
      .not()
      .isEmpty(),
    check("email", "Valid Email to be given").isEmail(),
    check("password", "Minimum 6 characters required").isLength({ min: 6 }),
    check("phone", "Phone No is required")
      .not()
      .isEmpty(),
    check("phone", "Valid Phone No is required")
      .isInt()
      .isLength({ min: 10 })
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { name, email, phone, password } = req.body;

    try {
      //See if the user email or phone no exists
      let user = await User.findOne({ email });
      if (user) {
        return res
          .status(400)
          .json({ errors: [{ msg: "User already exists" }] });
      }
      let userphone = await User.findOne({ phone });
      if (userphone) {
        return res
          .status(400)
          .json({ errors: [{ msg: "User Phone already exists" }] });
      }

      const avatar = gravatar.url(email, {
        s: "200",
        r: "pg",
        d: "mm"
      });

      user = new User({
        name,
        email,
        avatar,
        phone,
        password
      });

      const salt = await bcrypt.genSalt(10);
      user.password = await bcrypt.hash(password, salt);

      await user.save();

      const payload = {
        user: {
          id: user.id
        }
      };

      jwt.sign(
        payload,
        config.get("jwttoken"),
        { expiresIn: 360000 },
        (err, token) => {
          if (err) throw err;
          res.json({ token });
        }
      );
    } catch (err) {
      console.error(err.message);
      res.status(500).send("Server Error");
    }
  }
);

module.exports = router;
