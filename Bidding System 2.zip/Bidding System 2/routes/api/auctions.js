const express = require("express");
const router = express.Router();
const auth = require("../../middleware/auth");
const { check, validationResult } = require("express-validator");
const Product = require("../../models/Product");
const User = require("../../models/AuctionUser");
const Auction = require("../../models/Auction");

//  @route  GET /api/auctions
//  @desc   Get all auctions
//  @access public
router.get("/", async (req, res) => {
  try {
    auctions = await Auction.find();
    if (auctions.length === 0) return res.status(200).send("No Auctions");
    res.json(auctions);
  } catch (err) {
    console.error(err);
    res.json(500).send("Server Error");
  }
});

//  @route  POST /api/auctions/:product_id
//  @desc   Create an auction
//  @access private
router.post(
  "/:product_id",
  [
    auth,
    [
      check("specification", "Specification is required")
        .not()
        .isEmpty(),
      check("auctionType", "AuctionType is required")
        .not()
        .isEmpty(),
      check("auctionPurpose", "Auction Purpose is required")
        .not()
        .isEmpty(),
      check("productQuantity", "Quantity is required")
        .not()
        .isEmpty(),
      check("openingAuctionAmount", "Opening Auction Amount is required")
        .not()
        .isEmpty(),
      check("auctionOpeningDate", "Opening Date is required")
        .not()
        .isEmpty(),
      check("auctionClosingDate", "Closing Date is required")
        .not()
        .isEmpty(),
      check("deliveryLocation", "Delivery Location is required")
        .not()
        .isEmpty(),
      check("productSourceLocation", "Product Source Location is required")
        .not()
        .isEmpty()
    ]
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      console.error(errors);
      return res.status(400).json({ errors: errors.array() });
    }

    const {
      productQuantity,
      auctionType,
      auctionPurpose,
      specification,
      deliveryLocation,
      productSourceLocation,
      openingAuctionAmount,
      auctionOpeningDate,
      auctionClosingDate
    } = req.body;

    if (auctionPurpose != "Sell" && auctionPurpose != "Buy") {
      return res
        .status(400)
        .send("Auction Purpose needs to be either Buy or Sell");
    }

    if (auctionType != "Bid" && auctionType != "Open") {
      return res
        .status(400)
        .send("Auction Type needs to be either Bid or Open");
    }

    //Build auction Object
    const auctionFields = {};
    auctionFields.auctionType = auctionType;
    auctionFields.auctionPurpose = auctionPurpose;
    auctionFields.specification = specification;
    auctionFields.deliveryLocation = deliveryLocation;
    auctionFields.product = req.params.product_id;
    auctionFields.productSourceLocation = productSourceLocation;
    auctionFields.auctioneer = req.user.id;
    auctionFields.productQuantity = productQuantity;
    auctionFields.openingAuctionAmount = openingAuctionAmount;
    auctionFields.currentAuctionAmount = openingAuctionAmount;
    //If the auction is Open, then it is not bidding
    //If the auction is Bid, then the next Bidding Amount is incremental or decreased, depending on whether it is a Buy or Sell Auction

    if (auctionType == "Open")
      auctionFields.nextAuctionAmount = openingAuctionAmount;
    else {
      if (auctionPurpose == "Sell")
        auctionFields.nextAuctionAmount = openingAuctionAmount - 0 + 50;
      else auctionFields.nextAuctionAmount = openingAuctionAmount - 50;
    }

    auctionFields.auctionOpeningDate = auctionOpeningDate;
    auctionFields.auctionClosingDate = auctionClosingDate;

    auctionFields.openingAuctionTotalAmount =
      openingAuctionAmount * productQuantity;
    auctionFields.currentAuctionTotalAmount =
      auctionFields.openingAuctionTotalAmount;
    auctionFields.bids = [];

    try {
      auction = new Auction(auctionFields);
      await auction.save();
      res.json(auction);
    } catch (err) {
      console.error(err);
      res.status(500).send("Server Error");
    }
  }
);

//  @route  PUT /api/auctions/:auction_id/close
//  @desc   Close an auction
//  @access private
router.put("/:auction_id/close", auth, async (req, res) => {
  user = req.user.id;
  let auction = await Auction.findById(req.params.auction_id);
  if (user == auction.auctioneer) {
    auction.isClosed = true;
    Auction.findByIdAndUpdate(
      req.params.auction_id,
      auction,
      { new: true },
      (err, updatedauction) => {
        if (err) {
          return res.status(400).send("Update Error");
        }
        res.json(updatedauction);
      }
    );
  } else {
    return res.status(400).send("Only auctioneer can close an auction");
  }
});

//  @route  PUT /api/auctions/:auction_id/bid
//  @desc   Create a bid
//  @access private

//TODO: Need to add check for bid attributes that are required
router.put(
  "/:auction_id/bid",
  [
    auth,
    [
      check("bidQuantity", "Bid Quantity is required")
        .not()
        .isEmpty(),
      check("bidAmount", "Bid Amount is required")
        .not()
        .isEmpty()
    ]
  ],

  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      console.error(errors);
      return res.status(400).json({ errors: errors.array() });
    }

    user = req.user.id;
    let auction = await Auction.findById(req.params.auction_id);
    if (user == auction.auctioneer) {
      return res.status(400).send("Auctioneer cannot bid on their own auction");
    }

    if (auction.isClosed == true)
      return res.status(400).send("Auction has been closed");

    if (auction.auctionType == "Bid") {
      if (auction.auctionPurpose == "Sell") {
        if (req.body.bidAmount < auction.nextAuctionAmount)
          return res.status(400).send("Bid Amount too low");
      } else {
        if (req.body.bidAmount > auction.nextAuctionAmount)
          return res.status(400).send("Bid Amount too high");
      }
    }

    bidFields = {};
    bidFields.bidAmount = req.body.bidAmount;
    bidFields.bidQuantity = req.body.bidQuantity;
    bidFields.bidder = user;
    console.log("------AuctionType-------");
    console.log(auction.auctionType);
    if (auction.auctionType == "Bid") {
      auction.currentAuctionAmount = req.body.bidAmount;
      auction.currentAuctionTotalAmount =
        req.body.bidAmount * auction.productQuantity;
      if (auction.auctionPurpose == "Sell") {
        auction.nextAuctionAmount = req.body.bidAmount - 0 + 50; //TODO: This needs to be determined
      } else {
        auction.nextAuctionAmount = req.body.bidAmount - 50; //TODO: This needs to be determined
      }
    }

    auction.bids.unshift(bidFields);

    //TODO: This needs to be in a try catch block with an await function.
    Auction.findByIdAndUpdate(
      req.params.auction_id,
      auction,
      { new: true },
      (err, updatedauction) => {
        if (err) {
          return res.status(400).send("Update Error");
        }
        res.json(updatedauction);
      }
    );
  }
);

//  @route  Get /api/auctions/:auction_id/bid
//  @desc   Get all Bids
//  @access private
//  @return array of bid objects for the respective user. For the auctioneer, it returns an array of bids
router.get("/:auction_id/bid", auth, async (req, res) => {
  user = req.user.id;
  let auction = await Auction.findById(req.params.auction_id);

  if (user == auction.seller) {
    return res.json(auction.bids);
  }
  //Filter Bidders for this user
  let bidders = auction.bids.filter(bid => bid.bidder == user);
  if (bidders.length > 0) {
    //return this users bid
    return res.json(bidders);
  }

  return res.status(400).json({ msg: "You have not bid on this auction" });
});

//  @route  PUT /api/auctions/:auction_id/bid/:bid_id/accept
//  @desc   Accept a bid
//  @access private
router.put("/:auction_id/bid/:bid_id/accept", auth, async (req, res) => {
  user = req.user.id;
  let auction = await Auction.findById(req.params.auction_id);

  if (auction.isSuccessful) {
    return res.status(400).json({ msg: "Auction already accepted" });
  }

  if (auction.isClosed) {
    return res.status(400).json({ msg: "Auction already closed" });
  }

  if (user == auction.auctioneer) {
    //Need to find the bid from the array of bids.
    const bidIndex = auction.bids.findIndex(
      bid => bid._id == req.params.bid_id
    );
    bid = auction.bids[bidIndex];
    auction.bids[bidIndex].isSuccessful = true;
    auction.currentAuctionAmount = bid.bidAmount;
    auction.currentAuctionTotalAmount = bid.bidAmount * auction.productQuantity;
    auction.closedAuctionUnitAmount = bid.bidAmount;
    auction.closedAuctionTotalAmount = bid.bidAmount * auction.productQuantity;
    auction.isSuccessful = true;
    auction.isClosed = true;

    await Auction.findByIdAndUpdate(
      req.params.auction_id,
      { $set: auction },
      { new: true },
      (err, auction) => {
        if (!err) return res.json(auction);
        else {
          //throw { staus: 400, message: "Update error" };
          console.log(err);
          return res.status(400).send("Not updated");
        }
      }
    );
    //console.log(auction);
    //return res.json(auction);
  } else {
    return res.status(400).send("Only Auctioneer can accept a bid");
  }
});

module.exports = router;
