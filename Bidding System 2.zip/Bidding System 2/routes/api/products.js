const express = require("express");
const router = express.Router();
const { check, validationResult } = require("express-validator");
const Product = require("../../models/Product");
const auth = require("../../middleware/auth");

//  @route  GET /api/products
//  @desc   Get all product
//  @access public
//  @return ...

router.get("/", async (req, res) => {
  try {
    products = await Product.find();
    res.json(products);
  } catch (err) {
    console.log(err);
    res.status(500).error({ error: "Server Error" });
  }
});

//  @route  POST /api/products
//  @desc   Create a Product
//  @access private

router.post(
  "/",
  [
    auth,
    [
      check("name", "name is required")
        .not()
        .isEmpty(),
      check("quantityMetric", "Metric is required")
        .not()
        .isEmpty()
    ]
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    const {
      name,
      description,
      quantityMetric,
      minAuctionUnitAmount
    } = req.body;

    try {
      let productname = await Product.findOne({ name });
      if (productname) {
        return res.status(400).json({ errors: "Product Already exists" });
      }

      product = new Product({
        name,
        description,
        quantityMetric,
        minAuctionUnitAmount
      });

      await product.save();
      res.json({ product });
    } catch (err) {
      console.error(err);
      res.status(500).send("Server Error");
    }
  }
);

//  @route  PUT /api/products/:product_id
//  @desc   Update a Product
//  @access private

router.put("/:product_id", auth, async (req, res) => {
  const { name, description, quantityMetric, minAuctionUnitAmount } = req.body;

  try {
    let product = await Product.findById(req.params.product_id);
    if (product) {
      if (name) product.name = name;
      if (description) product.description = description;
      if (quantityMetric) product.quantityMetric = quantityMetric;
      if (minAuctionUnitAmount)
        product.minAuctionUnitAmount = minAuctionUnitAmount;
      await Product.findByIdAndUpdate(
        req.params.product_id,
        { $set: product },
        (err, prod) => {
          if (!err) res.json(prod);
          else {
            //throw { staus: 400, message: "Update error" };
            console.log(err);
            return res.status(400).send("Not updated");
          }
        }
      );
    } else {
      return res.status(400).send({ err: "Product not found" });
    }
  } catch (err) {
    console.error(err);
    res.status(err.status || 500).send(err.message || "Server Error");
  }
});

//  @route  Delete /api/products/:product_id
//  @desc   Delete a Product
//  @access private

router.delete("/:product_id", auth, async (req, res) => {
  try {
    product = await Product.findOneAndRemove({ id: req.params.product_id });
    if (product === null) {
      return res.status(400).send({ err: "Product does not exist" });
    }

    res.json({ msg: "Product deleted" });
  } catch (err) {
    console.error(err);
    res.status(500).send("Server Error");
  }
});

module.exports = router;
