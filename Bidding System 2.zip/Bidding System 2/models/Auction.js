/*
Auction
-- Description
-- ProductQualityParameters
-- Product
-- Seller
-- isClosed
-- isSuccessful
-- ProductQuantity
-- OpeningAuctionUnitAmount
-- CurrentAuctionUnitAmount
-- ClosedAuctionUnitAmount
-- OpeningAuctionTotalAmount
-- CurrentAuctionTotalAmount
-- ClosedAuctionTotalAmount
-- AuctionOpeningDateTime
-- AuctionClosingDateTime

Bid
-- AuctionId fk to Auction
-- BidderId fk to Bidder
-- CurrentBidUnitAmount
-- NextBidMinUnitAmount
*/

const mongoose = require("mongoose");

const AuctionSchema = new mongoose.Schema({
  auctionType: {
    type: String,
    required: true
  },

  auctionPurpose: {
    type: String,
    required: true
  },

  specification: {
    type: String,
    required: true
  },
  deliveryLocation: {
    type: String,
    required: true
  },
  product: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "product"
  },
  productSourceLocation: {
    type: String,
    required: true
  },
  auctioneer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "auctionuser"
  },
  isClosed: {
    type: Boolean,
    default: false
  },
  isSuccessful: {
    type: Boolean,
    default: false
  },
  productQuantity: {
    type: Number,
    required: true
  },
  openingAuctionAmount: {
    type: Number
  },
  currentAuctionAmount: {
    type: Number,
    required: true
  },
  nextAuctionAmount: {
    type: Number,
    required: true
  },
  closedAuctionUnitAmount: {
    type: Number
  },
  openingAuctionTotalAmount: {
    type: Number,
    required: true
  },
  currentAuctionTotalAmount: {
    type: Number,
    required: true
  },
  closedAuctionTotalAmount: {
    type: Number
  },
  auctionOpeningDate: {
    type: Date,
    required: true
  },
  auctionClosingDate: {
    type: Date,
    required: true
  },
  date: {
    type: Date,
    default: Date.now
  },

  bids: [
    {
      bidder: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "auctionuser"
      },
      bidQuantity: {
        type: Number,
        required: true
      },
      bidAmount: {
        type: Number,
        required: true
      },
      isSuccessful: {
        type: Boolean,
        default: false
      }
    }
  ]
});

module.exports = Auction = mongoose.model("auction", AuctionSchema);
