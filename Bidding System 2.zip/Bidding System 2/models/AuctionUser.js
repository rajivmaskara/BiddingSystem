const mongoose = require("mongoose");

const AuctionUserSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  email: {
    type: String,
    required: true,
    unique: true
  },
  password: {
    type: String,
    required: true
  },
  avatar: {
    type: String
  },
  phone: {
    type: Number,
    required: true,
    unique: true,
    min: 1000000000,
    max: 9999999999
  },
  isAdmin: {
    type: Boolean,
    default: false
  },
  date: {
    type: Date,
    default: Date.now
  }
});

module.exports = AuctionUser = mongoose.model("auctionuser", AuctionUserSchema);
