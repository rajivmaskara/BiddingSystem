/*
Requirement
-- Product
-- ProductSpecification
-- ProductQuantity
-- DeliveryLocation
-- DeliveryPeriod
-- PaymentTerms
-- Buyer
-- isClosed
-- isSuccessful
-- OpeningRequirementUnitAmount
-- CurrentRequirementUnitAmount
-- ClosedRequirementUnitAmount
-- OpeningRequirementTotalAmount
-- CurrentRequirementTotalAmount
-- ClosedRequirementTotalAmount
-- RequirementOpeningDateTime
-- RequirementClosingDateTime

Seller
-- RequirementId fk to Requirement
-- SellerId fk to Seller
-- CurrentBidUnitAmount
-- NextBidMinUnitAmount
*/
