const mongoose = require("mongoose");

const ProductSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    unique: true
  },
  description: {
    type: String
  },
  quantityMetric: {
    type: String,
    required: true
  },
  minAuctionUnitAmount: {
    type: Number,
    required: true
  }
});

module.exports = Product = mongoose.model("product", ProductSchema);
